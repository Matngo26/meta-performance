import { Info } from 'lucide-react';
import { metricConfig } from '@/lib/metrics/config';
import { formatMetric,originLabel } from '@/lib/utils/format';
import type { Report } from '@/types/domain';
export default function Kpis({report}:{report:Report|null}) {return <section aria-label="Indicadores principales" className="kpi-grid">{metricConfig.filter(m=>m.kpi).map((m,i)=>{const value=report?.summary[m.id];return <article className={`kpi ${i===0?'featured':''}`} key={m.id}><div className="kpi-label">{m.label}<span tabIndex={0} title={m.tooltip} aria-label={m.tooltip}><Info size={13}/></span></div><strong>{formatMetric(m.id,value,report?.account.currency??'')}</strong><small>{m.id==='results'&&report?.resultGroups.length===1?report.resultGroups[0].label:m.id==='results'&&report&&report.resultGroups.length>1?'Varios tipos · ver desglose':value?.value!=null?originLabel(value):report?'Sin valor aplicable':'Esperando conexión'}</small></article>;})}</section>;}
