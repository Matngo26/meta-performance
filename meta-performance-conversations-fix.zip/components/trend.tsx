'use client';
import {useState} from 'react';
import {AreaChart,Area,XAxis,YAxis,CartesianGrid,Tooltip,ResponsiveContainer} from 'recharts';
import {BarChart3} from 'lucide-react';
import type {Report} from '@/types/domain';
import {metricConfig,metricsById} from '@/lib/metrics/config';
import {formatMetric} from '@/lib/utils/format';
import {dateLabel} from '@/lib/utils/dates';
export default function Trend({report}:{report:Report|null}) {
 const [metric,setMetric]=useState('spend');const available=['spend','results','cost_per_result','impressions','link_clicks','link_ctr'];
 const data=report?.daily.map(p=>({date:p.date,value:p.metrics[metric]?.value==null?null:Number(p.metrics[metric].value)}))??[];const hasValues=data.some(d=>d.value!==null);
 return <section className="panel trend"><div className="section-heading"><div><h2>Evolución del rendimiento</h2><p>Una métrica, una escala. Todo el período seleccionado.</p></div><select aria-label="Métrica del gráfico" value={metric} onChange={e=>setMetric(e.target.value)}>{metricConfig.filter(m=>available.includes(m.id)).map(m=><option key={m.id} value={m.id}>{m.label}</option>)}</select></div>
 {hasValues?<><div className="chart-key"><span className="dot"/>{metricsById[metric].label}<span className="muted">{report?.source==='mock'?'MOCK':report?.account.currency}</span></div><div className="chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={data} margin={{top:12,right:16,bottom:0,left:0}}><defs><linearGradient id="fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#16836d" stopOpacity={.2}/><stop offset="100%" stopColor="#16836d" stopOpacity={.01}/></linearGradient></defs><CartesianGrid strokeDasharray="3 5" vertical={false} stroke="#e6ebe8"/><XAxis dataKey="date" tickFormatter={d=>dateLabel(d).slice(0,5)} axisLine={false} tickLine={false} minTickGap={36} tick={{fill:'#77847f',fontSize:11}}/><YAxis width={60} tickFormatter={v=>new Intl.NumberFormat('es-PY',{notation:'compact',maximumFractionDigits:1}).format(v)} axisLine={false} tickLine={false} tick={{fill:'#77847f',fontSize:11}}/><Tooltip labelFormatter={v=>dateLabel(String(v))} formatter={v=>[formatMetric(metric,{value:String(v),source:report?.source??'unavailable'},report?.account.currency??''),metricsById[metric].label]} contentStyle={{border:'1px solid #dce5df',borderRadius:9,fontSize:12}}/><Area type="linear" dataKey="value" stroke="#16836d" strokeWidth={2} fill="url(#fill)" connectNulls={false} isAnimationActive={false}/></AreaChart></ResponsiveContainer></div></>:<div className="chart-empty"><BarChart3 size={30}/><strong>{report?'No hay valores comparables para esta métrica':'Tu rendimiento, en perspectiva'}</strong><span>{report?'Para resultados y costos, seleccioná una campaña u objetivo con un mismo tipo de resultado.':'El gráfico se completará al conectar una fuente de datos de Ads.'}</span></div>}
 </section>;
}
