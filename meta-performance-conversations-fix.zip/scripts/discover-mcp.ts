import { discoverMcp } from '../lib/mcp/client';
if(!process.env.META_MCP_URL){console.error('Configurá META_MCP_URL en el entorno del servidor. Nunca pegues secretos en el frontend.');process.exitCode=1;}
else {try {const audit=await discoverMcp(process.env.META_MCP_URL,process.env.META_MCP_BEARER);console.log(JSON.stringify(audit,null,2));}catch{console.error('No se pudo inspeccionar el MCP. Verificá URL, autenticación y permisos en el servidor.');process.exitCode=1;}}
