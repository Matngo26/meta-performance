import ts from 'typescript';
import { mkdir,readFile,writeFile,readdir } from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
const root=process.cwd(),target=path.join(root,'.sites-runtime/test-build');
async function transpile(directory){for(const entry of await readdir(path.join(root,directory),{withFileTypes:true})){const relative=path.join(directory,entry.name);if(entry.isDirectory()){await transpile(relative);continue;}if(!relative.endsWith('.ts')||relative.endsWith('.d.ts'))continue;const source=await readFile(path.join(root,relative),'utf8');const output=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,esModuleInterop:true},fileName:relative}).outputText.replace(/from\s+(['"])([^'"]+)\1/g,(match,quote,id)=>{if(!id.startsWith('.')&&!id.startsWith('@/'))return match;const resolved=id.startsWith('@/')?path.join(target,id.slice(2)):path.resolve(target,path.dirname(relative),id);let result=path.relative(path.join(target,path.dirname(relative)),resolved).replaceAll('\\','/');if(!result.startsWith('.'))result='./'+result;return `from ${quote}${result.replace(/\.ts$/,'')}.mjs${quote}`;});const destination=path.join(target,relative.replace(/\.ts$/,'.mjs'));await mkdir(path.dirname(destination),{recursive:true});await writeFile(destination,output);}}
for(const directory of ['lib','types','tests'])await transpile(directory);
const result=spawnSync(process.execPath,['--test',path.join(target,'tests/domain.test.mjs')],{stdio:'inherit'});
process.exitCode=result.status??1;

