# Investigación del MCP · 13/10/2026

## Evidencia

Se inspeccionaron las herramientas visibles de `MCP | META`, se ejecutó `devtools_app_list` con `limit:50` y se consultó `devtools_discovery`. El listado respondió correctamente y sin página siguiente. Sus registros son aplicaciones de desarrollador. Sus identificadores y configuraciones no se incorporan como cuentas publicitarias.

| Herramienta real | Acciones expuestas | Función |
|---|---|---|
| devtools_api_changelog | list_products, get_changelog_url, get_rss_url | Cambios públicos de plataforma |
| devtools_api_usage | rate_limits, call_volume, deprecations | Salud de API por aplicación |
| devtools_app | basic_settings, advanced_settings, security, restrictions, data_protection_officer | Configuración de aplicaciones |
| devtools_app_list | list | Aplicaciones autorizadas; paginación por cursor |
| devtools_app_review | status, history, privileges, requirements | Revisión de aplicaciones |
| devtools_compliance | status | Cumplimiento de aplicaciones |
| devtools_discovery | search_docs | Documentación pública |
| devtools_skill_invocation | start, end | Observabilidad de skills |
| devtools_webhook_list | list_topics, list_subscriptions | Suscripciones webhook |
| devtools_webhook_manage | subscribe, unsubscribe, update_fields | Escrituras webhook; no utilizadas |
| devtools_webhook_test | test_send | Envío de prueba; no utilizado |

No hay herramienta expuesta de cuentas publicitarias, campañas, conjuntos, anuncios o insights. Ningún nivel publicitario fue consultable. No se dispone de recursos de Ads mediante esta conexión. Los límites de DevTools no permiten inferir cuotas, lotes, campos, histórico o atribución del servidor de Ads.

## Métricas

**NO DISPONIBLE DIRECTAMENTE** significa aquí: el MCP conectado no ofrece una consulta que la devuelva. Los campos son referencias de Marketing API y deben verificarse nuevamente contra la herramienta real de Ads. Tampoco puede calcularse ninguna métrica real mientras falten sus componentes.

| Métrica | Disponible en este MCP | Fuente/campo de referencia | Requiere cálculo | Observación |
|---|---|---|---|---|
| Inversión | NO DISPONIBLE DIRECTAMENTE | spend | No | Moneda de la cuenta |
| Resultados | NO DISPONIBLE DIRECTAMENTE | actions, results, objective_results | Selección/normalización | El SDK actual también contiene campos de resultados; no se afirma que el MCP los exponga |
| Costo por resultado | NO DISPONIBLE DIRECTAMENTE | cost_per_result, cost_per_action_type o inversión/resultados | Sí en esta implementación | Validar el resultado y ámbito |
| Impresiones | NO DISPONIBLE DIRECTAMENTE | impressions | No | No duplicar breakdowns |
| Alcance | NO DISPONIBLE DIRECTAMENTE | reach | No | Consulta única de todo el ámbito |
| Frecuencia | NO DISPONIBLE DIRECTAMENTE | frequency | Impresiones/alcance | Mismo período y ámbito |
| CPM | NO DISPONIBLE DIRECTAMENTE | cpm | Inversión/impresiones × 1.000 | No promediar filas |
| Clics enlace | NO DISPONIBLE DIRECTAMENTE | inline_link_clicks | No | Diferente de clics totales |
| CTR enlace | NO DISPONIBLE DIRECTAMENTE | inline_link_click_ctr | Clics enlace/impresiones × 100 | No usar clicks |
| Clics totales | NO DISPONIBLE DIRECTAMENTE | clicks | No | Todos los clics |
| CPC enlace | NO DISPONIBLE DIRECTAMENTE | cost_per_inline_link_click | Inversión/clics enlace | Denominador cero produce null |
| CPC general | NO DISPONIBLE DIRECTAMENTE | cpc | Inversión/clicks | Misma atribución |
| CTR general | NO DISPONIBLE DIRECTAMENTE | ctr | clicks/impresiones × 100 | Separado de CTR enlace |
| Video | NO DISPONIBLE DIRECTAMENTE | Campos video_* y actions | Según evento | Definir duración/evento |
| Landing Page Views | NO DISPONIBLE DIRECTAMENTE | actions, acción validada | Selección | No sustituir silenciosamente por clics |
| Leads | NO DISPONIBLE DIRECTAMENTE | actions, acción validada | Selección | Distinguir formulario, web u otro destino |
| Compras | NO DISPONIBLE DIRECTAMENTE | actions, acción validada | Selección | No sumar purchase y sus alias |
| Valor de conversión | NO DISPONIBLE DIRECTAMENTE | action_values | Selección | Desambiguar acción y moneda |
| ROAS | NO DISPONIBLE DIRECTAMENTE | purchase_roas o valor de compras/inversión | Posible | Misma ventana de atribución |
| Interacciones | NO DISPONIBLE DIRECTAMENTE | actions o inline_post_engagement | Selección | Según optimización |
| Mensajes | NO DISPONIBLE DIRECTAMENTE | Acción de mensajería por verificar | Selección | No confundir mensaje con conversación |
| Conversaciones iniciadas | NO DISPONIBLE DIRECTAMENTE | Acción por verificar | Selección | No inventar action_type |
| Formularios completados | NO DISPONIBLE DIRECTAMENTE | Acción por verificar | Selección | Evitar doble conteo con leads |
| Añadir al carrito | NO DISPONIBLE DIRECTAMENTE | Acción por verificar | Selección | Ventana y destino coherentes |
| Checkout iniciado | NO DISPONIBLE DIRECTAMENTE | Acción por verificar | Selección | No equivale a compra |

## Fuentes oficiales consultadas

- [Meta Social Technologies MCP](https://developers.facebook.com/documentation/mcp/devtools-mcp): objeto del servidor conectado, herramientas y autenticación.
- [Meta Ads MCP](https://developers.facebook.com/documentation/mcp/ads-mcp-server): producto separado para publicidad.
- [Anuncio de Ads MCP](https://developers.facebook.com/blog/post/2026/07/16/meta-ads-mcp-server/): disponibilidad gradual de herramientas; la documentación no acredita acceso en esta sesión.
- [Ads Insights API](https://developers.facebook.com/documentation/ads-commerce/marketing-api/insights): niveles y consultas de referencia.
- [SDK de Meta: AdsInsights](https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/adsinsights.py): catálogo de campos de referencia, no prueba de disponibilidad MCP.
- [SDK oficial de MCP](https://github.com/modelcontextprotocol/typescript-sdk): transporte y descubrimiento.
