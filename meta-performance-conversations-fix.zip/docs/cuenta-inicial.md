# Cuenta inicial del dashboard

La cuenta inicial seleccionada para el desarrollo es:

- **Nombre:** NGO - Cliente
- **Account ID:** `973686847473174`
- **Moneda informada por Meta:** USD
- **Estado:** ACTIVE
- **Ads MCP:** habilitado
- **Consultable:** sí

El MCP devolvió campañas reales de esta cuenta para `last_30d`, incluyendo objetivos `OUTCOME_ENGAGEMENT`, `OUTCOME_SALES` y `OUTCOME_TRAFFIC`. Los resultados fueron reportados por Meta con su indicador de acción; por ejemplo, conversaciones iniciadas para campañas de mensajes y clics en el enlace para tráfico.

La versión visual inicial usa datos sintéticos etiquetados como `DATOS DE DESARROLLO / MOCK`, pero ya queda asociada a este ID para que la integración server-only pueda reemplazar la fuente sin cambiar los componentes de UI.
