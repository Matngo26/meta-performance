# Validación

## Comprobado

20 pruebas automatizadas del motor: precisión decimal y enteros grandes, null frente a cero, denominadores cero, elección de resultado, ambigüedad de compra, no sumar objetivos diferentes, CPM/CTR sobre componentes originales, alcance deduplicado sintético, conservación de inversión entre niveles, IDs, filtros, fechas, zonas horarias, moneda, caché, force refresh, fallos, paginación, relaciones huérfanas, aislamiento de cuenta/atribución y espera de rate limit.

Las pruebas usan exclusivamente fixtures y datos sintéticos. No demuestran correspondencia con Meta.

Verificación visual local: la página inicial muestra la conexión pendiente y métricas vacías. El modo MOCK carga indicadores, tabla y gráfico; el filtro de campaña y la selección de nivel actualizan el mismo ámbito. Los resultados mixtos muestran desglose; una campaña homogénea muestra cantidad y costo.

## Conciliación real pendiente — bloqueo de capacidad

| Comprobación | Estado | Condición de aceptación |
|---|---|---|
| Cuentas y permisos | Pendiente | Coinciden con cuentas accesibles de Meta Ads |
| Campaña / conjunto / anuncio | Pendiente | IDs y jerarquía sin asociaciones por nombres |
| Inversión | Pendiente | Decimal de Meta coincide antes de formato |
| Impresiones y clics | Pendiente | Mismo ámbito, filtros y rango |
| Alcance | Pendiente | Totales consultados al nivel/ámbito correcto, sin sumas de únicos |
| CPM y CTR | Pendiente | Componentes coinciden; diferencia sólo por redondeo visual |
| Resultados | Pendiente | Optimización, acción, destino y evento correctos |
| Costo por resultado | Pendiente | Inversión y resultados comparables en misma atribución |
| Fecha, moneda y zona | Pendiente | Configuración de cuenta y rango inclusivo verificados |
| Estado | Pendiente | Estado efectivo recibido; original conservado por adaptador |
| Refresh y límites | Pendiente | Lectura real trazable, 429/timeouts y Retry-After comprobados |
| Autorización entre clientes | Pendiente | Identidad y ACL de cuenta reales verificadas |

Para comparar, alinear Ads Manager y API en fechas, timezone, moneda, filtros, nivel, ventanas de atribución y fecha de reporte de acciones. Registrar respuesta original en almacenamiento privado seguro (no frontend), resultado normalizado y diferencias; repetir sólo las comprobaciones afectadas por cambios. Revisar si Meta marca métricas como estimadas o demoradas.

**No declarar terminado el MVP conectado hasta completar esta tabla con una cuenta real.**
