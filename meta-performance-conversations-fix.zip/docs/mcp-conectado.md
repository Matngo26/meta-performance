# MCP de Meta Ads conectado

La disponibilidad del MCP se validó con llamadas de solo lectura durante esta sesión.

## Capacidades observadas

- `ads_get_ad_accounts`: devolvió 6 cuentas accesibles, con moneda, negocio, estado, `is_ads_mcp_enabled` e `is_queryable`.
- `ads_get_field_context`: confirmó campos y niveles válidos. Entre ellos: gasto, resultados, costo por resultado, impresiones, alcance, frecuencia, CPM, clics de enlace, CTR, clics, objetivo y estado efectivo.
- `ads_get_ad_entities`: consultó campañas reales de la cuenta `973686847473174` para `last_30d`. La respuesta incluyó gasto, resultados, costo por resultado, impresiones, alcance, frecuencia, CPM, clics y CTR.

El MCP devuelve `ad_entities` como JSON serializado y exige validar los campos mediante `ads_get_field_context` antes de cada consulta. La paginación usa `pagination.next_cursor`. Una cuenta puede aparecer accesible pero estar deshabilitada para Ads MCP; esas cuentas no se consultan.

## Límite de runtime

La llamada nativa disponible en ChatGPT valida el conector, pero no convierte sus credenciales en una API pública para el navegador. Por eso el dashboard conserva un adaptador server-only (`MetaDataProvider`) y requiere configurar `META_MCP_URL` en el runtime de Vercel o un bridge interno compatible con Streamable HTTP. Nunca se deben colocar tokens en variables `NEXT_PUBLIC_*`.

Mientras ese bridge no esté configurado, la interfaz muestra datos `DATOS DE DESARROLLO / MOCK` y el modo real devuelve un estado explícito de conexión pendiente; no mezcla datos simulados con datos reales.
