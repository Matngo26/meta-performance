# Bridge MCP de Meta Ads

El proyecto incluye un bridge server-only en `POST /api/mcp`. El bridge implementa `tools/list` y `tools/call` para:

- `get_ad_accounts`
- `get_ad_entities`
- `get_field_context`

El bridge llama a Meta Marketing API con `META_ACCESS_TOKEN`; el token nunca se envía al navegador.

## Configuración en Codespaces o Vercel

Configurar como secretos del entorno:

```env
META_ACCESS_TOKEN=...
META_GRAPH_API_VERSION=v23.0
META_MCP_BEARER=un-token-largo-y-aleatorio
```

Para que la aplicación use el bridge remoto en lugar de llamar directamente a Graph API:

```env
META_MCP_URL=https://tu-dominio.example.com/api/mcp
META_MCP_BEARER=el-mismo-token-configurado-en-el-bridge
```

En un despliegue de una sola aplicación se puede omitir `META_MCP_URL`: el dashboard utilizará `META_ACCESS_TOKEN` directamente desde el servidor. En una arquitectura separada, el dashboard usa `META_MCP_URL` y el bridge conserva `META_ACCESS_TOKEN`.

## Prueba de salud

```text
GET https://tu-dominio.example.com/api/mcp
```

Devuelve estado público del bridge, pero las operaciones requieren `Authorization: Bearer ...`.

## Seguridad

- No usar prefijos `NEXT_PUBLIC_` para tokens.
- No guardar `.env.local` en Git.
- Usar un token distinto por entorno y rotarlo si se sospecha exposición.
- El bridge solo expone operaciones de lectura; no crea ni modifica campañas.
