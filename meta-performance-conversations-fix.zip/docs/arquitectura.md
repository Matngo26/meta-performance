# Arquitectura y modelo

```mermaid
flowchart LR
 UI[React: filtros, KPIs, gráfico, tabla] --> API[API privada y validación]
 API --> CACHE[Caché por usuario, cuenta, modo y consulta]
 CACHE --> PROVIDER[AdsProvider]
 PROVIDER --> MCP[MCP de Ads validado]
 MCP --> NORMALIZE[Normalización y relaciones por ID]
 NORMALIZE --> METRICS[Catálogo de métricas y reglas de resultados]
 METRICS --> REPORT[Report interno]
 REPORT --> UI
```

El modo de desarrollo usa un proveedor separado que cumple el mismo contrato. No utiliza respuestas del MCP ni cambia a mocks ante errores. El backend real está explícitamente bloqueado porque faltan operaciones Ads.

## Relaciones

```mermaid
erDiagram
 Account ||--o{ Campaign : accountId
 Campaign ||--o{ AdSet : campaignId
 AdSet ||--o{ Ad : adSetId
 Account ||--o{ Insight : accountId
 Insight ||--o{ Metric : values
 Insight ||--|| ResultMetric : primaryResult
```

Account: ID, tenant, nombre, currency ISO y timezone IANA. Campaign: ID, accountId, objetivo y estado. AdSet: ID, accountId, campaignId, optimización y estado. Ad: ID, accountId, campaignId, adSetId y estado. Insight: nivel, entityId, IDs disponibles, since/until inclusivos, atribución, métricas y resultado.

Metric conserva decimal en string o null, origen (`meta`, `calculated`, `mock`, `unavailable`), campo y motivo de ausencia. ResultMetric conserva tipo, nombre, cantidad, costo y regla aplicada. El tooltip identifica origen. No se redondea para cálculos; el formato se aplica únicamente al presentar. Tampoco se convierte a Number para formatear enteros grandes. El gráfico sí convierte a Number para coordenadas visuales.

## Contrato que debe implementar el proveedor real

`capabilities()` verifica operaciones y disponibilidad. `accounts(scope)` lista cuentas autorizadas. `report(scope,query)` devuelve un reporte completo, con jerarquía, métricas al nivel seleccionado, resumen del ámbito filtrado y serie diaria. No debe devolver totales de la primera página como totales generales.

Pasos del adaptador real:

1. Validar identidad y permiso de cuenta mediante la conexión del visitante, nunca un ID recibido como autorización.
2. Resolver filtros a IDs con metadata paginada; mantener registros eliminados si insights aún los devuelve. La búsqueda afecta el mismo universo que tabla, KPIs y gráfico.
3. Consultar insights del nivel elegido, resumen del ámbito completo y serie diaria. Alcance y frecuencia requieren consultas con el ámbito completo, no sumas entre días/entidades.
4. Conservar atribución (ventanas, tiempo de reporte, configuración de conjunto) y fecha explícita. No mezclar conversiones con contextos distintos.
5. Resolver resultados por optimización, objetivo y evento/destino verificados. Los objetivos amplios como OUTCOME_SALES y OFFSITE_CONVERSIONS no prueban por sí solos que el evento sea compra.
6. Devolver warnings para estimaciones, restricciones y datos incompletos. La política actual rechaza páginas parciales para evitar totales engañosos; puede ampliarse a una vista parcial rotulada.

La regla de resultados recibe acciones ya desambiguadas semánticamente. No suma tipos de acción solapados. Si existen resultados de tipos distintos, devuelve desglose y `null` para el total/costo general. Dentro de un tipo comparable: costo = suma de inversión / suma de resultados. Si el resultado es alcance, requiere alcance único del grupo.

## Carpetas

```text
app/                   Página y API same-origin
components/            Dashboard, KPIs, gráfico, filtros, tabla
types/domain.ts        Entidades, métricas, consultas y proveedor
lib/mcp/               Inventario observado, proveedor pendiente, cliente de descubrimiento
lib/normalization/     Campos de referencia y relaciones
lib/metrics/           Catálogo, resultados y agregación
lib/state/             Estado inicial y contrato de filtros
lib/cache/             TTL, límites y agrupación de solicitudes
lib/services/          Proveedor mock, errores, paginación y rate limits
lib/utils/             Decimales, fechas, formato y estados
scripts/               Desarrollo, build, auditoría MCP y pruebas
tests/                 Casos de cálculo y contrato
docs/                  Investigación, decisiones y validación
```

## Límites deliberados del MVP actual

Una cuenta por vista evita sumar monedas. La selección de un estado filtra el estado actual al nivel seleccionado, no el estado histórico. Las etiquetas desconocidas se preservan y no se deducen estados a partir de fechas. El proveedor futuro debe devolver el estado efectivo y conservar el original cuando exista; Programado/Finalizado sólo se mostrarán si la fuente realmente ofrece esa clasificación.

La caché dura 60 segundos y admite 100 consultas por proceso. La clave incluye usuario/tenant, proveedor, cuenta, fechas, nivel y filtros. Forzar actualización invalida la respuesta almacenada; solicitudes simultáneas para la misma clave comparten la petición en curso. Errores no se cachean. El frontend aborta solicitudes obsoletas y aplica timeout de 30 segundos. No hay polling automático.

La utilidad paginada limita 100 páginas / 50.000 filas, detecta cursores repetidos y rechaza respuestas parciales. Los grandes reportes deben migrar a consulta asíncrona/paginación de servidor según capacidades comprobadas. No se inventaron límites de Meta.

Futuro: separar tenantId de userId con membresías persistentes; reemplazar caché en memoria por cache backend; versionar MetricDefinition y ResultRule; persistir snapshots con fecha, atribución y versión; agregar consultas de comparación previa mediante el mismo contrato; exportaciones y alertas consumirán Report, nunca responses crudas de Meta. No se implementaron estas extensiones.
