create extension if not exists pgcrypto;

create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.tenant_members (
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'viewer' check (role in ('owner','admin','analyst','viewer')),
  created_at timestamptz not null default now(),
  primary key (tenant_id, user_id)
);

create or replace function public.is_tenant_member(p_tenant_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.tenant_members m
    where m.tenant_id = p_tenant_id and m.user_id = auth.uid()
  );
$$;

create table if not exists public.ad_accounts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  external_id text not null,
  name text not null,
  business_id text,
  business_name text,
  currency char(3) not null,
  timezone text,
  provider text not null default 'meta_mcp',
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, external_id)
);

create table if not exists public.campaigns (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  ad_account_id uuid not null references public.ad_accounts(id) on delete cascade,
  external_id text not null,
  name text not null,
  objective text,
  status text,
  effective_status text,
  unique (tenant_id, external_id)
);

create table if not exists public.ad_sets (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  ad_account_id uuid not null references public.ad_accounts(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete set null,
  external_id text not null,
  name text not null,
  optimization_goal text,
  status text,
  effective_status text,
  unique (tenant_id, external_id)
);

create table if not exists public.ads (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  ad_account_id uuid not null references public.ad_accounts(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete set null,
  ad_set_id uuid references public.ad_sets(id) on delete set null,
  external_id text not null,
  name text not null,
  status text,
  effective_status text,
  unique (tenant_id, external_id)
);

create table if not exists public.insight_rows_daily (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  ad_account_id uuid not null references public.ad_accounts(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete cascade,
  ad_set_id uuid references public.ad_sets(id) on delete cascade,
  ad_id uuid references public.ads(id) on delete cascade,
  day date not null,
  attribution_window text,
  objective text,
  result_type text,
  results numeric,
  spend numeric,
  impressions bigint,
  reach bigint,
  link_clicks bigint,
  clicks bigint,
  conversion_value numeric,
  raw jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (tenant_id, ad_account_id, campaign_id, ad_set_id, ad_id, day, attribution_window)
);

create table if not exists public.dashboard_links (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  ad_account_id uuid not null references public.ad_accounts(id) on delete cascade,
  token_hash text not null unique,
  label text,
  expires_at timestamptz,
  revoked_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.sync_runs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  ad_account_id uuid references public.ad_accounts(id) on delete set null,
  provider text not null,
  status text not null check (status in ('running','success','partial','failed')),
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  rows_synced integer not null default 0,
  error_code text,
  error_message text
);

create index if not exists insight_rows_daily_lookup on public.insight_rows_daily (tenant_id, ad_account_id, day);
create index if not exists insight_rows_daily_entity on public.insight_rows_daily (tenant_id, ad_id, day);
create index if not exists dashboard_links_active on public.dashboard_links (token_hash, revoked_at, expires_at);

alter table public.tenants enable row level security;
alter table public.tenant_members enable row level security;
alter table public.ad_accounts enable row level security;
alter table public.campaigns enable row level security;
alter table public.ad_sets enable row level security;
alter table public.ads enable row level security;
alter table public.insight_rows_daily enable row level security;
alter table public.dashboard_links enable row level security;
alter table public.sync_runs enable row level security;

create policy tenant_member_read on public.tenants for select using (public.is_tenant_member(id));
create policy tenant_member_self_read on public.tenant_members for select using (user_id = auth.uid() or public.is_tenant_member(tenant_id));

create policy ad_accounts_isolated on public.ad_accounts for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));
create policy campaigns_isolated on public.campaigns for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));
create policy ad_sets_isolated on public.ad_sets for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));
create policy ads_isolated on public.ads for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));
create policy insights_isolated on public.insight_rows_daily for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));
create policy links_isolated on public.dashboard_links for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));
create policy sync_isolated on public.sync_runs for all using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

create or replace function public.resolve_dashboard_link(p_token_hash text)
returns table (tenant_id uuid, ad_account_id uuid, expires_at timestamptz)
language sql stable security definer set search_path = public as $$
  select l.tenant_id, l.ad_account_id, l.expires_at
  from public.dashboard_links l
  where l.token_hash = p_token_hash
    and l.revoked_at is null
    and (l.expires_at is null or l.expires_at > now());
$$;
revoke all on function public.resolve_dashboard_link(text) from public;
grant execute on function public.resolve_dashboard_link(text) to anon, authenticated;
