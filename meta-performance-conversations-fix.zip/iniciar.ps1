$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$taskNode = Get-Command node -ErrorAction SilentlyContinue
if ($taskNode) { $taskNodePath = $taskNode.Source } else {
  $taskNodePath = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
}
if (-not (Test-Path -LiteralPath $taskNodePath)) { throw 'Se requiere Node.js 22.13 o superior.' }
if (-not (Test-Path -LiteralPath 'node_modules')) { throw 'Ejecutá pnpm install antes de iniciar.' }
& $taskNodePath --import ./scripts/sites-env.mjs ./scripts/run-framework.mjs dev
