export type Level = 'campaign' | 'adset' | 'ad';
export type DecimalValue = string | null;
export type Source = 'meta' | 'calculated' | 'mock' | 'unavailable';
export interface Metric { value: DecimalValue; source: Source; field?: string; reason?: string }
export interface Account { id: string; tenantId: string; name: string; currency: string; timezone: string }
export interface Campaign { id: string; accountId: string; name: string; objective: string; status: string }
export interface AdSet { id: string; accountId: string; campaignId: string; name: string; optimizationGoal: string; status: string }
export interface Ad { id: string; accountId: string; campaignId: string; adSetId: string; name: string; status: string }
export type ResultKind = 'conversations' | 'leads' | 'landing_page_views' | 'link_clicks' | 'purchases' | 'reach' | 'engagement' | 'video';
export interface ResultMetric { kind: ResultKind | null; label: string; count: Metric; cost: Metric; rule: string }
export interface Insight { accountId: string; level: Level | 'account'; entityId: string; campaignId?: string; adSetId?: string; adId?: string; since: string; until: string; attribution: string; metrics: Record<string, Metric>; result: ResultMetric }
export interface ReportRow extends Insight { campaignName: string; adSetName: string; adName: string; status: string; objective: string; optimizationGoal: string }
export interface Hierarchy { campaigns: Campaign[]; adSets: AdSet[]; ads: Ad[] }
export interface Filters { search: string; campaignId: string; adSetId: string; adId: string; status: string; objective: string }
export interface Query { accountId: string; since: string; until: string; level: Level; filters: Filters }
export interface Report { account: Account; query: Query; rows: ReportRow[]; hierarchy: Hierarchy; summary: Record<string, Metric>; resultGroups: {kind: ResultKind; label: string; count: Metric; cost: Metric}[]; daily: {date: string; metrics: Record<string, Metric>}[]; fetchedAt: string; source: 'meta' | 'mock'; complete: boolean; warnings: string[] }
export interface CapabilityReport { status: 'unsupported' | 'ready' | 'unconfigured'; provider: string; message: string; tools: string[]; operations: Record<'accounts'|'campaigns'|'adsets'|'ads'|'insights', boolean> }
export interface RequestScope { tenantId: string; userId: string }
export interface Page<T> { data: T[]; nextCursor?: string; complete: boolean }
export interface AdsProvider { capabilities(): Promise<CapabilityReport>; accounts(scope: RequestScope): Promise<Account[]>; report(scope: RequestScope, query: Query): Promise<Report> }
