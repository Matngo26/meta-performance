import type { Filters } from '@/types/domain';
export const emptyFilters:Filters={search:'',campaignId:'',adSetId:'',adId:'',status:'',objective:''};
