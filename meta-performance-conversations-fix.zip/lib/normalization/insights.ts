import type { Metric,ResultKind } from '@/types/domain';
import { metricConfig,calculateMetrics } from '@/lib/metrics/config';
import { getPrimaryResult } from '@/lib/metrics/results';
import { received,missing } from '@/lib/utils/numbers';
// Reference Graph field normalizer, not an assumed MCP response shape.
export function normalizeFields(raw:Record<string,unknown>,objective:string,goal:string,semanticActions:Partial<Record<ResultKind,Metric>>,verifiedKind?:ResultKind,source:'meta'|'mock'='meta') {
 const base:Record<string,Metric>={};for(const d of metricConfig) if(d.type==='additive'||d.type==='unique') base[d.id]=received(raw[d.metaFields[0]],d.metaFields[0],source);
 const result=getPrimaryResult(objective,goal,semanticActions,base.spend??missing(),verifiedKind);
 base.results=result.count;base.cost_per_result=result.cost;return {metrics:calculateMetrics(base),result};
}
