import type {Hierarchy,Insight,ReportRow} from '@/types/domain';
export function enrichInsight(insight:Insight,hierarchy:Hierarchy):ReportRow {
 const campaign=hierarchy.campaigns.find(c=>c.id===insight.campaignId&&c.accountId===insight.accountId);
 const adSet=hierarchy.adSets.find(s=>s.id===insight.adSetId&&s.accountId===insight.accountId&&s.campaignId===insight.campaignId);
 const ad=hierarchy.ads.find(a=>a.id===insight.adId&&a.accountId===insight.accountId&&a.campaignId===insight.campaignId&&a.adSetId===insight.adSetId);
 const entity=insight.level==='ad'?ad:insight.level==='adset'?adSet:campaign;
 return {...insight,campaignName:campaign?.name??(insight.campaignId?'Entidad no disponible':''),adSetName:adSet?.name??(insight.adSetId?'Entidad no disponible':''),adName:ad?.name??(insight.adId?'Entidad no disponible':''),status:entity?.status??'',objective:campaign?.objective??'',optimizationGoal:adSet?.optimizationGoal??''};
}
