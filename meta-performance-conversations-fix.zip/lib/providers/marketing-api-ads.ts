import type { AdsProvider, Account, Query, Report, ReportRow, RequestScope, Metric, ResultKind } from '@/types/domain';
import { observedCapabilities } from '@/lib/mcp/capabilities';
import { DataError } from '@/lib/services/errors';
import { normalizeFields } from '@/lib/normalization/insights';
import { received, missing } from '@/lib/utils/numbers';
import { aggregate } from '@/lib/metrics/aggregate';
import { addDays } from '@/lib/utils/dates';
import { serverEnv } from '@/lib/config/server-env';

type Json = Record<string, unknown>;
type GraphPage = { data?: Json[]; paging?: { next?: string } };
const API_VERSION = serverEnv('META_GRAPH_API_VERSION') || 'v23.0';
const GRAPH = `https://graph.facebook.com/${API_VERSION}`;
const fields = ['spend','impressions','reach','frequency','inline_link_clicks','clicks','actions','action_values','campaign_id','campaign_name','adset_id','adset_name','ad_id','ad_name','date_start','date_stop','objective','optimization_goal'];

function accountPath(id: string) { return id.startsWith('act_') ? id : `act_${id}`; }
function str(v: unknown, fallback = '') { return typeof v === 'string' ? v : v == null ? fallback : String(v); }
function resultAction(raw: unknown, kind: ResultKind): Metric {
  const actions = Array.isArray(raw) ? raw as Json[] : [];
  const aliases: Record<ResultKind, string[]> = {
    conversations: ['messaging_conversation_started','messaging_conversation_started_7d','onsite_conversion.messaging_conversation_started','onsite_conversion.messaging_conversation_started_7d','messaging_first_reply','conversation_started'],
    leads: ['lead','offsite_conversion.fb_pixel_lead','onsite_conversion.lead_grouped'],
    landing_page_views: ['landing_page_view'], link_clicks: ['link_click'], purchases: ['purchase'],
    reach: [], engagement: ['post_engagement'], video: ['video_view','thruplay'],
  };
  const match = actions.find(a => {
    const actionType = str(a.action_type).toLowerCase();
    return aliases[kind].some(alias => actionType === alias) || (kind === 'conversations' && actionType.includes('messag') && actionType.includes('conversation'));
  });
  return match ? received(match.value, `actions.${str(match.action_type)}`, 'meta') : missing(`Acción ${kind} no disponible para este registro`);
}
function hasConversationAction(raw: unknown): boolean {
  return Array.isArray(raw) && (raw as Json[]).some(action => {
    const actionType = str(action.action_type).toLowerCase();
    return actionType.includes('messag') && (actionType.includes('conversation') || actionType.includes('reply'));
  });
}
function actionKind(objective: string, goal: string): ResultKind | undefined {
  const byGoal: Record<string, ResultKind> = { CONVERSATIONS:'conversations', LEAD_GENERATION:'leads', LANDING_PAGE_VIEWS:'landing_page_views', LINK_CLICKS:'link_clicks', REACH:'reach', POST_ENGAGEMENT:'engagement', THRUPLAY:'video', OFFSITE_CONVERSIONS:'purchases' };
  if (byGoal[goal]) return byGoal[goal];
  const byObjective: Record<string, ResultKind> = { OUTCOME_ENGAGEMENT:'engagement', OUTCOME_LEADS:'leads', OUTCOME_TRAFFIC:'link_clicks', OUTCOME_SALES:'purchases', OUTCOME_AWARENESS:'reach' };
  return byObjective[objective];
}
function toRow(raw: Json, accountId: string, since: string, until: string): ReportRow {
  const objective = str(raw.objective, ''); const goal = str(raw.optimization_goal, '');
  const kind = actionKind(objective, goal) ?? (hasConversationAction(raw.actions) ? 'conversations' : undefined);
  const normalized = normalizeFields(raw, objective, goal, kind ? { [kind]: resultAction(raw.actions, kind) } : {}, kind, 'meta');
  return { accountId, level:'ad', entityId:str(raw.ad_id), campaignId:str(raw.campaign_id), adSetId:str(raw.adset_id), adId:str(raw.ad_id), campaignName:str(raw.campaign_name,'Campaña sin nombre'), adSetName:str(raw.adset_name,'Conjunto sin nombre'), adName:str(raw.ad_name,'Anuncio sin nombre'), status:str(raw.effective_status,'UNKNOWN'), objective, optimizationGoal:goal, since, until, attribution:'Meta Ads · configuración predeterminada', ...normalized };
}

class GraphClient {
  constructor(private readonly token: string) {}
  async get(path: string, params: Record<string,string> = {}): Promise<Json> {
    const url = new URL(path.startsWith('http') ? path : `${GRAPH}/${path.replace(/^\//,'')}`);
    url.searchParams.set('access_token', this.token);
    for (const [key, value] of Object.entries(params)) url.searchParams.set(key, value);
    const response = await fetch(url, { cache:'no-store', signal: AbortSignal.timeout(90000) });
    const body = await response.json().catch(() => ({})) as Json;
    if (!response.ok || body.error) throw new DataError('META_API_ERROR', str((body.error as Json|undefined)?.message,'Meta Marketing API rechazó la solicitud.'), response.status === 429 ? 429 : 502, response.status === 429 ? 30 : undefined);
    return body;
  }
}

export class MarketingApiAdsProvider implements AdsProvider {
  private client() { const token = serverEnv('META_ACCESS_TOKEN'); if (!token) throw new DataError('MARKETING_API_NOT_CONFIGURED','Falta META_ACCESS_TOKEN en los secretos del servidor.',503); return new GraphClient(token); }
  async capabilities() { const ready=Boolean(serverEnv('META_ACCESS_TOKEN')); return {...observedCapabilities,status: ready ? 'ready' as const : 'unconfigured' as const,provider:'Meta Marketing API',message: ready ? 'Conectado mediante Graph API server-only.' : 'Falta META_ACCESS_TOKEN en el runtime server-only.',tools:['GET /me/adaccounts','GET /{account}/insights','GET /{account}/campaigns','GET /{account}/adsets','GET /{account}/ads'],operations:{accounts:ready,campaigns:ready,adsets:ready,ads:ready,insights:ready}}; }
  async accounts(scope: RequestScope): Promise<Account[]> {
    const page = await this.client().get('me/adaccounts', { fields:'id,name,currency,timezone,account_status', limit:'100' }) as GraphPage;
    return (page.data ?? []).map(row => ({id:str(row.id),tenantId:scope.tenantId,name:str(row.name,'Cuenta sin nombre'),currency:str(row.currency,'USD'),timezone:str(row.timezone,'UTC')}));
  }
  private async insights(accountId: string, query: Query, level: string, timeIncrement?: string): Promise<Json[]> {
    const page = await this.client().get(`${accountPath(accountId)}/insights`, { level, fields:fields.join(','), time_range:JSON.stringify({since:query.since,until:query.until}), ...(timeIncrement ? {time_increment:timeIncrement} : {}), limit:'500' }) as GraphPage;
    return page.data ?? [];
  }
  async report(_scope: RequestScope, query: Query): Promise<Report> {
    const client = this.client(); const accounts = await this.accounts(_scope); const account = accounts.find(a => a.id === query.accountId);
    if (!account) throw new DataError('ACCOUNT_DENIED','No tenés acceso a esta cuenta.',403);
    const [raw, accountRows, dailyRaw] = await Promise.all([this.insights(account.id, query, query.level), this.insights(account.id, query, 'account'), this.insights(account.id, query, 'account', '1')]);
    const rows = raw.map(r => toRow(r,account.id,query.since,query.until));
    const accountRaw = accountRows[0];
    const scopeRow = accountRaw ? toRow({...accountRaw, ad_id:'account',adset_id:'',campaign_id:''},account.id,query.since,query.until) : undefined;
    const rowAggregate = aggregate(rows);
    const summary = scopeRow ? {...scopeRow.metrics, results:rowAggregate.summary.results, cost_per_result:rowAggregate.summary.cost_per_result} : rowAggregate.summary;
    const dailyMap = new Map<string, ReportRow[]>();
    for (const item of dailyRaw) { const row=toRow(item,account.id,str(item.date_start,query.since),str(item.date_stop,query.until)); const date=str(item.date_start,query.since); dailyMap.set(date,[...(dailyMap.get(date)??[]),row]); }
    const daily=[]; for(let date=query.since;date<=query.until;date=addDays(date,1)) daily.push({date,metrics:aggregate(dailyMap.get(date)??[]).summary});
    const hierarchy={campaigns:[...new Map(rows.map(r=>[r.campaignId??'',{id:r.campaignId??'',accountId:account.id,name:r.campaignName,objective:r.objective,status:r.status}])).values()],adSets:[...new Map(rows.map(r=>[r.adSetId??'',{id:r.adSetId??'',accountId:account.id,campaignId:r.campaignId??'',name:r.adSetName,optimizationGoal:r.optimizationGoal,status:r.status}])).values()],ads:[...new Map(rows.map(r=>[r.adId??'',{id:r.adId??'',accountId:account.id,campaignId:r.campaignId??'',adSetId:r.adSetId??'',name:r.adName,status:r.status}])).values()]};
    return {account,query,rows:rows.map(r=>({...r,level:query.level})),hierarchy,summary,resultGroups:rowAggregate.resultGroups,daily,fetchedAt:new Date().toISOString(),source:'meta',complete:true,warnings:[]};
  }
}
