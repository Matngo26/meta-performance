import type { Account, Level, Report } from '@/types/domain';

export type ProviderQuery = {
  adAccountId: string;
  level: Level;
  since: string;
  until: string;
  fields?: string[];
  cursor?: string;
};

export type ProviderCapabilities = {
  provider: 'marketing_api' | 'mcp';
  accounts: boolean;
  campaigns: boolean;
  adSets: boolean;
  ads: boolean;
  insights: boolean;
  maxPageSize?: number;
  notes: string[];
};

export interface MetaDataProvider {
  capabilities(): Promise<ProviderCapabilities>;
  getAccounts(): Promise<Account[]>;
  getReport(query: ProviderQuery): Promise<Report>;
}

export class MarketingApiProvider implements MetaDataProvider {
  async capabilities(): Promise<ProviderCapabilities> {
    return { provider: 'marketing_api', accounts: true, campaigns: true, adSets: true, ads: true, insights: true, notes: ['Implementar con token de servidor y paginación de Graph API.'] };
  }
  async getAccounts(): Promise<Account[]> { throw new Error('MARKETING_API_NOT_CONFIGURED'); }
  async getReport(): Promise<Report> { throw new Error('MARKETING_API_NOT_CONFIGURED'); }
}

export class McpMetaAdsProvider implements MetaDataProvider {
  async capabilities(): Promise<ProviderCapabilities> {
    return { provider: 'mcp', accounts: true, campaigns: true, adSets: true, ads: true, insights: true, maxPageSize: 50, notes: ['Requiere META_MCP_URL en el runtime servidor.', 'El MCP devuelve ad_entities como JSON serializado.', 'Debe verificarse field_context antes de consultar campos.'] };
  }
  async getAccounts(): Promise<Account[]> { throw new Error('META_MCP_BRIDGE_NOT_CONFIGURED'); }
  async getReport(): Promise<Report> { throw new Error('META_MCP_BRIDGE_NOT_CONFIGURED'); }
}

export function createMetaDataProvider(): MetaDataProvider {
  return process.env.META_MCP_URL ? new McpMetaAdsProvider() : new MarketingApiProvider();
}
