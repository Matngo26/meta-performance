export class DataError extends Error {constructor(public code:string,message:string,public status=502,public retryAfter?:number){super(message);}}
export function safeError(error:unknown) {return error instanceof DataError?{code:error.code,message:error.message,retryAfter:error.retryAfter}:{code:'CONNECTION_ERROR',message:'No se pudo consultar la fuente. Intentá nuevamente.'};}
