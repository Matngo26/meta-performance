import type { Account,AdsProvider,Hierarchy,Query,Report,ReportRow,ResultKind,Metric } from '@/types/domain';
import { observedCapabilities } from '@/lib/mcp/capabilities';
import { received,sum } from '@/lib/utils/numbers';
import { normalizeFields } from '@/lib/normalization/insights';
import { aggregate } from '@/lib/metrics/aggregate';
import { addDays } from '@/lib/utils/dates';
import { DataError } from './errors';
export const demoAccounts:Account[]=[{id:'973686847473174',tenantId:'development',name:'NGO - Cliente · DATOS DE DESARROLLO / MOCK',currency:'USD',timezone:'America/Asuncion'},{id:'mock-pyg',tenantId:'development',name:'Estudio Demo · Paraguay',currency:'PYG',timezone:'America/Asuncion'},{id:'mock-usd',tenantId:'development',name:'Estudio Demo · Internacional',currency:'USD',timezone:'America/New_York'}];
export function demoHierarchy(accountId:string):Hierarchy {
 const campaigns=[{id:'demo-c1',accountId,name:'Conversaciones · Octubre',objective:'OUTCOME_ENGAGEMENT',status:'ACTIVE'},{id:'demo-c2',accountId,name:'Catálogo · Conversiones',objective:'OUTCOME_SALES',status:'ACTIVE'},{id:'demo-c3',accountId,name:'Contenido · Visitas web',objective:'OUTCOME_TRAFFIC',status:'PAUSED'}];
 const adSets=campaigns.map((c,i)=>({id:`demo-s${i+1}`,accountId,campaignId:c.id,name:['Asunción · Audiencia amplia','Remarketing · 30 días','Intereses · Diseño'][i],optimizationGoal:['CONVERSATIONS','OFFSITE_CONVERSIONS','LANDING_PAGE_VIEWS'][i],status:c.status}));
 const ads=Array.from({length:6},(_,i)=>({id:`demo-ad${i+1}`,accountId,campaignId:campaigns[Math.floor(i/2)].id,adSetId:adSets[Math.floor(i/2)].id,name:['Video · Nuestra propuesta','Carrusel · Colección nueva','Producto · Más vendidos','Video · En uso','Editorial · La historia','Imagen · Descubrí más'][i],status:['ACTIVE','ACTIVE','ACTIVE','PENDING_REVIEW','CAMPAIGN_PAUSED','PAUSED'][i]}));return {campaigns,adSets,ads};
}
type Slice={row:ReportRow;people:Set<number>;date:string};
function union(slices:Slice[]) {const people=new Set<number>();for(const s of slices) for(const id of s.people) people.add(id);return received(people.size,'synthetic_unique_people','mock');}
export function createDemoReport(query:Query):Report {
 const account=demoAccounts.find(a=>a.id===query.accountId);if(!account)throw new DataError('ACCOUNT_DENIED','Cuenta no disponible.',403);
 const hierarchy=demoHierarchy(account.id),f=query.filters,slices:Slice[]=[];
 for(let date=query.since;date<=query.until;date=addDays(date,1)) {
 const day=Math.floor(Date.parse(date)/86400000);
 hierarchy.ads.forEach((ad,i)=>{
  const campaign=hierarchy.campaigns.find(c=>c.id===ad.campaignId)!,adset=hierarchy.adSets.find(s=>s.id===ad.adSetId)!;
  const status=query.level==='campaign'?campaign.status:query.level==='adset'?adset.status:ad.status;
  const match=[campaign.name,adset.name,ad.name,ad.id,campaign.id,adset.id].join(' ').toLowerCase();
  if((f.campaignId&&f.campaignId!==campaign.id)||(f.adSetId&&f.adSetId!==adset.id)||(f.adId&&f.adId!==ad.id)||(f.status&&f.status!==status)||(f.objective&&f.objective!==campaign.objective)||(f.search&&!match.includes(f.search.toLowerCase())))return;
  const factor=4+(day+i*3)%9,impressions=factor*830+i*400,reach=Math.round(impressions/1.9),spend=account.currency==='PYG'?factor*3200+i*1700:(factor*3.2+i*1.7).toFixed(2),linkClicks=factor*17+i*9;
  const kind:ResultKind=i<2?'conversations':i<4?'purchases':'landing_page_views';
  const value=kind==='purchases'?factor:kind==='conversations'?factor*4:factor*13;
  const people=new Set(Array.from({length:reach},(_,n)=>(n+i*731+day*197)%30000));
  const normalized=normalizeFields({spend,impressions,reach,inline_link_clicks:linkClicks,clicks:linkClicks+factor*7},campaign.objective,adset.optimizationGoal,{[kind]:received(value,'synthetic_result','mock')},kind,'mock');
  slices.push({date,people,row:{accountId:account.id,level:'ad',entityId:ad.id,campaignId:campaign.id,adSetId:adset.id,adId:ad.id,campaignName:campaign.name,adSetName:adset.name,adName:ad.name,status,objective:campaign.objective,optimizationGoal:adset.optimizationGoal,since:date,until:date,attribution:'MOCK · Sin atribución Meta',...normalized}});
 });}
 function grouped(input:Slice[],level:Query['level']):ReportRow[] {const buckets=new Map<string,Slice[]>();for(const s of input){const key=level==='campaign'?s.row.campaignId!:level==='adset'?s.row.adSetId!:s.row.adId!;buckets.set(key,[...(buckets.get(key)??[]),s]);}
 return [...buckets.entries()].map(([id,group])=>{const first=group[0].row;const a=aggregate(group.map(s=>s.row),union(group));const kind=first.result.kind;const metrics=a.summary;return {...first,level,entityId:id,adId:level==='ad'?id:undefined,adSetId:level==='campaign'?undefined:first.adSetId,adName:level==='ad'?first.adName:'',adSetName:level==='campaign'?'':first.adSetName,since:query.since,until:query.until,metrics,result:{...first.result,kind,count:metrics.results,cost:metrics.cost_per_result}};});}
 const leaf=grouped(slices,'ad'),totals=aggregate(leaf,union(slices)),rows=grouped(slices,query.level);
 const daily=[];for(let date=query.since;date<=query.until;date=addDays(date,1)){const selected=slices.filter(s=>s.date===date);daily.push({date,metrics:aggregate(selected.map(s=>s.row),union(selected)).summary});}
 return {account,query,rows,hierarchy,...totals,daily,fetchedAt:new Date().toISOString(),source:'mock',complete:true,warnings:['DATOS DE DESARROLLO / MOCK. No provienen de Meta Ads.','Los estados describen la situación actual; el rango filtra métricas históricas.']};
}
export const demoProvider:AdsProvider={async capabilities(){return {...observedCapabilities,status:'ready',provider:'DATOS DE DESARROLLO / MOCK'};},async accounts(){return demoAccounts;},async report(_scope,query){return createDemoReport(query);}};
