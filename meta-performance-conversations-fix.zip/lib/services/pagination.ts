import type { Page } from '@/types/domain';
import { DataError } from './errors';
export async function collectPages<T>(fetchPage:(cursor?:string)=>Promise<Page<T>>,maxPages=100,maxRows=50000) {
 const rows:T[]=[];const seen=new Set<string>();let cursor:string|undefined;
 for(let page=0;page<maxPages;page++) {const result=await fetchPage(cursor);if(!result.complete) throw new DataError('PARTIAL','La fuente devolvió datos parciales. No se muestran como totales.');rows.push(...result.data);if(rows.length>maxRows) throw new DataError('VOLUME_LIMIT','El volumen excede el límite. Reducí el rango o los filtros.',422);if(!result.nextCursor) return rows;if(seen.has(result.nextCursor)) throw new DataError('PAGINATION_LOOP','La fuente repitió una página.');seen.add(result.nextCursor);cursor=result.nextCursor;}
 throw new DataError('PAGE_LIMIT','La consulta requiere un rango más pequeño.',422);
}
