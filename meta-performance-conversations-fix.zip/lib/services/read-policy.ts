import {DataError} from './errors';
// Apply only to verified read operations; never replay writes or timed-out operations.
export async function readWithRateLimit<T>(read:()=>Promise<T>,sleep=(ms:number)=>new Promise<void>(r=>setTimeout(r,ms)),maxRetries=2):Promise<T> {
 for(let attempt=0;;attempt++)try{return await read();}catch(error){if(!(error instanceof DataError)||error.code!=='RATE_LIMIT'||attempt>=maxRetries)throw error;const seconds=error.retryAfter??2**attempt;if(seconds>30)throw error;await sleep(Math.max(0,seconds)*1000);}
}
