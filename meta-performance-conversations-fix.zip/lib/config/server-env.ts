/** Reads server-only variables across Node/Vinext and Cloudflare/Vite runtimes. */
export function serverEnv(name: string): string | undefined {
  const nodeValue = typeof process !== 'undefined' ? process.env[name] : undefined;
  if (nodeValue) return nodeValue;
  const viteEnv = (import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env;
  return viteEnv?.[name] || undefined;
}
