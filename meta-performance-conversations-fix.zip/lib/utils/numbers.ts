import Decimal from 'decimal.js';
import type { Metric, Source } from '@/types/domain';
Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP });
export const missing = (reason = 'NO DISPONIBLE DIRECTAMENTE'): Metric => ({value:null,source:'unavailable',reason});
export function numeric(input: unknown): string | null {
 if (input === null || input === undefined || input === '' || typeof input === 'boolean') return null;
 if (typeof input !== 'string' && typeof input !== 'number') return null;
 try { const d = new Decimal(input); return d.isFinite() && !d.isNegative() ? d.toString() : null; } catch { return null; }
}
export function received(input: unknown, field: string, source: Source = 'meta'): Metric { const value=numeric(input);return value===null?missing(`Campo ${field} ausente o inválido`):{value,field,source}; }
export function ratio(a: Metric,b: Metric,multiplier=1): Metric { if(a.value===null||b.value===null||new Decimal(b.value).isZero()) return missing('Sin componentes suficientes o denominador cero');return {value:new Decimal(a.value).div(b.value).mul(multiplier).toString(),source:a.source==='mock'||b.source==='mock'?'mock':'calculated'}; }
export function sum(values: Metric[]): Metric { if(!values.length||values.some(x=>x.value===null)) return missing('No hay un conjunto completo de valores');return {value:values.reduce((total,v)=>total.plus(v.value!),new Decimal(0)).toString(),source:values.some(v=>v.source==='mock')?'mock':'calculated'}; }
export const compare=(a:string,b:string)=>new Decimal(a).cmp(b);
