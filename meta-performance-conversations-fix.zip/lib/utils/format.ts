import type { Metric } from '@/types/domain';
import { metricsById } from '@/lib/metrics/config';
import Decimal from 'decimal.js';
export function formatMetric(id:string,metric:Metric|undefined,currency:string) {
 if(metric?.value==null) return '—';let value:Decimal;try{value=new Decimal(metric.value);}catch{return '—';}if(!value.isFinite())return '—';const config=metricsById[id];const decimals=config?.format==='money'&&currency==='PYG'?0:config?.decimals??0;
 const [whole,fraction]=value.toFixed(decimals).split('.');const text=whole.replace(/\B(?=(\d{3})+(?!\d))/g,'.')+(fraction?','+fraction:'');
 return config?.format==='money'?`${currency==='PYG'?'₲':currency} ${text}`:config?.format==='percent'?`${text} %`:id==='roas'?`${text}×`:text;
}
export const originLabel=(m?:Metric)=>m?.source==='meta'?'Recibido de Meta':m?.source==='calculated'?'Calculado por la aplicación':m?.source==='mock'?'DATOS DE DESARROLLO / MOCK':m?.reason??'No disponible';
