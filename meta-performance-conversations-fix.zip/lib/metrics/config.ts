import type { Level, Metric } from '@/types/domain';
import { ratio, missing } from '@/lib/utils/numbers';
export type Format = 'money'|'integer'|'decimal'|'percent';
export interface MetricDefinition { id:string; metaFields:string[]; label:string; type:'additive'|'unique'|'ratio'|'result'; format:Format; decimals:number; availability:string; levels:(Level|'account')[]; tooltip:string; calculate?:(m:Record<string,Metric>)=>Metric; defaultColumn?:boolean; kpi?:boolean }
const levels:MetricDefinition['levels']=['account','campaign','adset','ad'];
const metric=(id:string,label:string,metaFields:string[],format:Format,type:MetricDefinition['type'],tooltip:string,extra:Partial<MetricDefinition>={}):MetricDefinition=>({id,label,metaFields,format,type,tooltip,decimals:format==='integer'?0:2,availability:'Pendiente de verificar en el MCP de Ads',levels,defaultColumn:true,...extra});
const div=(a:string,b:string,k=1)=>(m:Record<string,Metric>)=>ratio(m[a]??missing(),m[b]??missing(),k);
export const metricConfig:MetricDefinition[]=[
metric('spend','Inversión',['spend'],'money','additive','Importe del período en la moneda de la cuenta.',{kpi:true}),
metric('results','Conversaciones con mensajes iniciadas',['actions','results','objective_results'],'integer','result','Conversaciones iniciadas según la acción validada y la optimización de Meta.',{kpi:true}),
metric('cost_per_result','Costo por conversación con mensajes iniciada',[],'money','ratio','Inversión / conversaciones con mensajes iniciadas. Sin conversaciones: —.',{kpi:true}),
metric('reach','Alcance',['reach'],'integer','unique','Personas únicas del ámbito completo. Nunca se suman alcances diarios o de anuncios.',{kpi:true}),
metric('impressions','Impresiones',['impressions'],'integer','additive','Cantidad de impresiones del período.',{kpi:true}),
metric('cpm','CPM',['cpm'],'money','ratio','Inversión / impresiones × 1.000.',{calculate:div('spend','impressions',1000),kpi:true}),
metric('link_clicks','Clics enlace',['inline_link_clicks'],'integer','additive','Clics en enlaces; no equivale a clics totales.',{kpi:true}),
metric('link_ctr','CTR enlace',['inline_link_click_ctr'],'percent','ratio','Clics en enlace / impresiones × 100.',{calculate:div('link_clicks','impressions',100),kpi:true}),
metric('clicks','Clics totales',['clicks'],'integer','additive','Todos los clics reportados por Meta.'),
metric('frequency','Frecuencia',['frequency'],'decimal','ratio','Impresiones / alcance del mismo ámbito.',{calculate:div('impressions','reach')}),
metric('link_cpc','CPC enlace',['cost_per_inline_link_click'],'money','ratio','Inversión / clics en enlace.',{calculate:div('spend','link_clicks'),defaultColumn:false}),
metric('cpc','CPC general',['cpc'],'money','ratio','Inversión / clics totales.',{calculate:div('spend','clicks'),defaultColumn:false}),
metric('ctr','CTR general',['ctr'],'percent','ratio','Clics totales / impresiones × 100.',{calculate:div('clicks','impressions',100),defaultColumn:false}),
metric('conversion_value','Valor conversión',['action_values'],'money','additive','Valor de compra validado; no sumar alias.',{defaultColumn:false}),
metric('roas','ROAS',['purchase_roas'],'decimal','ratio','Valor de compras / inversión con la misma atribución.',{calculate:div('conversion_value','spend'),defaultColumn:false}),
];
export const metricsById=Object.fromEntries(metricConfig.map(m=>[m.id,m]));
export function calculateMetrics(base:Record<string,Metric>) {const result={...base};for(const m of metricConfig) if(m.calculate) result[m.id]=m.calculate(result);return result;}
