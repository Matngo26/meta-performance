import type { Metric,ResultKind,ResultMetric } from '@/types/domain';
import { missing,ratio } from '@/lib/utils/numbers';
export const resultLabels:Record<ResultKind,string>={conversations:'Conversaciones con mensajes iniciadas',leads:'Leads',landing_page_views:'Visitas a destino',link_clicks:'Clics en enlace',purchases:'Compras',reach:'Personas alcanzadas',engagement:'Interacciones',video:'Reproducciones de video'};
// Providers validate action aliases and conversion destination before assigning semantics.
export function getPrimaryResult(objective:string,optimizationGoal:string,actions:Partial<Record<ResultKind,Metric>>,spend:Metric,verifiedKind?:ResultKind):ResultMetric {
 const goals:Record<string,ResultKind>={CONVERSATIONS:'conversations',LEAD_GENERATION:'leads',LANDING_PAGE_VIEWS:'landing_page_views',LINK_CLICKS:'link_clicks',REACH:'reach',POST_ENGAGEMENT:'engagement',THRUPLAY:'video'};
 const legacy:Record<string,ResultKind>={MESSAGES:'conversations',LEAD_GENERATION:'leads',LINK_CLICKS:'link_clicks',REACH:'reach'};
 const kind=verifiedKind??goals[optimizationGoal]??(!optimizationGoal?legacy[objective]:undefined);
 if(!kind) return {kind:null,label:'Resultado sin determinar',count:missing('Objetivo u optimización ambiguos; validar evento y destino'),cost:missing(),rule:'unresolved'};
 const count=actions[kind]??missing(`No se recibió ${resultLabels[kind]}`);
 return {kind,label:resultLabels[kind],count,cost:ratio(spend,count),rule:verifiedKind?'provider-verified':`optimization:${optimizationGoal||objective}`};
}
