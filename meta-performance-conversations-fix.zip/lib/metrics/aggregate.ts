import type { Metric,ReportRow,ResultKind } from '@/types/domain';
import { metricConfig,calculateMetrics } from './config';
import { missing,ratio,sum } from '@/lib/utils/numbers';
export function aggregate(rows:ReportRow[],scopeReach:Metric=missing('Requiere consulta de alcance para este ámbito')) {
 if(new Set(rows.map(r=>r.accountId)).size>1||new Set(rows.map(r=>r.attribution)).size>1)throw new Error('No se pueden agregar cuentas o atribuciones distintas.');
 const base:Record<string,Metric>={};for(const d of metricConfig) if(d.type==='additive') base[d.id]=sum(rows.map(r=>r.metrics[d.id]??missing()));base.reach=scopeReach;
 const kinds=[...new Set(rows.map(r=>r.result.kind))];
 const resultGroups=kinds.filter((k):k is ResultKind=>k!==null).map(kind=>{const matching=rows.filter(r=>r.result.kind===kind);const count=kind==='reach'?(kinds.length===1?scopeReach:missing('Alcance único por grupo no disponible')):sum(matching.map(r=>r.result.count));return {kind,label:matching[0].result.label,count,cost:ratio(sum(matching.map(r=>r.metrics.spend)),count)};});
 const comparable=kinds.length===1&&kinds[0]!==null;base.results=comparable?resultGroups[0].count:missing('Resultados heterogéneos: consultar desglose por tipo');base.cost_per_result=comparable?ratio(base.spend,base.results):missing('Resultados heterogéneos');return {summary:calculateMetrics(base),resultGroups};
}
