export class QueryCache<T> {
 private values=new Map<string,{expires:number,value:T}>();private inflight=new Map<string,Promise<T>>();
 constructor(private ttl=60000,private maxEntries=100){}
 async get(key:string,load:()=>Promise<T>,force=false):Promise<T> {
  const cached=this.values.get(key);if(!force&&cached&&cached.expires>Date.now()) return cached.value;
  const running=this.inflight.get(key);if(running)return running;
  if(force)this.values.delete(key);
  const pending=load().then(value=>{if(this.values.size>=this.maxEntries)this.values.delete(this.values.keys().next().value!);this.values.set(key,{value,expires:Date.now()+this.ttl});return value;}).finally(()=>this.inflight.delete(key));this.inflight.set(key,pending);return pending;
 }
 clear(){this.values.clear();}
}
