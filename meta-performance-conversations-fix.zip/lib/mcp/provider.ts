import type { AdsProvider, Account, Query, Report, RequestScope } from '@/types/domain';
import { observedCapabilities } from './capabilities';
import { DataError } from '@/lib/services/errors';
import { MarketingApiAdsProvider } from '@/lib/providers/marketing-api-ads';
import { serverEnv } from '@/lib/config/server-env';
// Only a reviewed, explicit provider may replace this adapter. Never infer Ads actions from DevTools.
const marketing = new MarketingApiAdsProvider();
class RemoteMcpProvider implements AdsProvider {
 private async call(name:string,args:Record<string,unknown>) {
  const url=serverEnv('META_MCP_URL'); const bearer=serverEnv('META_MCP_BEARER');
  if(!url||!bearer) throw new DataError('MCP_NOT_CONFIGURED','Faltan META_MCP_URL o META_MCP_BEARER en los secretos del servidor.',503);
  const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${bearer}`},body:JSON.stringify({jsonrpc:'2.0',id:Date.now(),method:'tools/call',params:{name,arguments:args}}),cache:'no-store',signal:AbortSignal.timeout(30000)});
  const body=await response.json().catch(()=>({})) as any;
  if(!response.ok||body.error) throw new DataError('MCP_BRIDGE_ERROR',body.error?.data?.message??'El bridge MCP rechazó la solicitud.',response.status===429?429:502);
  const text=body.result?.content?.find((item:any)=>item.type==='text')?.text;
  if(typeof text!=='string') throw new DataError('MCP_RESPONSE','Respuesta inválida del bridge MCP.',502);
  try{return JSON.parse(text);}catch{throw new DataError('MCP_RESPONSE','El bridge devolvió JSON inválido.',502);}
 }
 async capabilities(){return {...observedCapabilities,status:'ready' as const,provider:'MCP Meta Ads bridge',message:'Bridge MCP remoto configurado en runtime server-only.',tools:['get_ad_accounts','get_ad_entities','get_field_context'],operations:{accounts:true,campaigns:true,adsets:true,ads:true,insights:true}};}
 async accounts(_scope:RequestScope){return await this.call('get_ad_accounts',{}) as Account[];}
 async report(_scope:RequestScope,query:Query){return await this.call('get_ad_entities',{account_id:query.accountId,since:query.since,until:query.until,level:query.level}) as Report;}
}
const remote = new RemoteMcpProvider();
export const metaProvider:AdsProvider={
 async capabilities(){
  if(serverEnv('META_MCP_URL'))return remote.capabilities();
  return marketing.capabilities();
 },
 async accounts(scope){return serverEnv('META_MCP_URL')?remote.accounts(scope):marketing.accounts(scope);},
 async report(scope,query){return serverEnv('META_MCP_URL')?remote.report(scope,query):marketing.report(scope,query);},
};
