import { Client,StreamableHTTPClientTransport } from '@modelcontextprotocol/client';
import { collectPages } from '@/lib/services/pagination';
// Server/CLI only. Endpoint and credentials come from a trusted server configuration.
// No browser route accepts URLs, tokens, tool names, or arbitrary tool arguments.
export async function discoverMcp(endpoint:string,bearer?:string) {
 const url=new URL(endpoint);if(url.protocol!=='https:'||url.username||url.password||url.search) throw new Error('Se requiere un endpoint HTTPS sin credenciales ni query.');
 const client=new Client({name:'meta-performance-audit',version:'0.1.0'});
 const transport=new StreamableHTTPClientTransport(url,{requestInit:{headers:bearer?{Authorization:`Bearer ${bearer}`}:{},redirect:'error'}});
 const timer=setTimeout(()=>void client.close(),30000);
 try {await client.connect(transport);const caps=client.getServerCapabilities();
 const tools=caps?.tools?await collectPages(async cursor=>{const p=await client.listTools({cursor});return {data:p.tools,nextCursor:p.nextCursor,complete:true};},20):[];
 const resources=caps?.resources?await collectPages(async cursor=>{const p=await client.listResources({cursor});return {data:p.resources,nextCursor:p.nextCursor,complete:true};},20):[];
 const templates=caps?.resources?await collectPages(async cursor=>{const p=await client.listResourceTemplates({cursor});return {data:p.resourceTemplates,nextCursor:p.nextCursor,complete:true};},20):[];
 return {tools,resources,templates,capabilities:caps};
 }finally{clearTimeout(timer);await client.close();}
}
