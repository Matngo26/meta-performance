# Adscope · Meta Performance

Dashboard modular de marketing construido con React, TypeScript y Vinext. **La interfaz y el motor funcionan; el MVP con datos reales está bloqueado por las capacidades del MCP conectado.**

El 13/10/2026 se inspeccionó `MCP | META`. Expone 11 herramientas de **Meta Social Technologies / DevTools**, no herramientas de Meta Ads. La llamada real `devtools_app_list` respondió correctamente: lista aplicaciones de desarrollador, no cuentas de anuncios. No se consultaron métricas de publicidad ni se almacenaron datos reales de clientes en este proyecto.

## Ejecutar

Requiere Node >=22.13 y pnpm 11.25.0.

```sh
pnpm install
pnpm dev
```

Abrir la dirección que imprime el servidor, normalmente `http://127.0.0.1:5173/`. En el equipo donde se creó este proyecto también puede ejecutarse `./iniciar.ps1` desde PowerShell; usa el runtime instalado de Codex si Node no está en PATH.

El modo inicial muestra la conexión pendiente y ningún valor ficticio. **Probar con datos MOCK** activa un proveedor sintético aislado. El aviso `DATOS DE DESARROLLO / MOCK` permanece visible. Volver a Meta limpia las cifras. Los mocks nunca son una alternativa automática a un error del proveedor real.

```sh
pnpm test
pnpm typecheck
pnpm build
```

## Implementado

- Selector de cuenta, moneda y zona horaria; cuentas sintéticas PYG/USD para pruebas.
- Campañas, conjuntos y anuncios relacionados por IDs.
- Períodos rápidos y personalizados; límite inicial de 93 días.
- Filtros globales por nombre/ID, campaña, conjunto, anuncio, estado y objetivo.
- Ocho KPIs, desglose de resultados heterogéneos, gráfico de métrica seleccionable.
- Tabla con orden ascendente/descendente, columnas ocultables y reordenables, encabezado fijo, scroll y paginación visual.
- Catálogo central de métricas, decimal.js, procedencia y valores nulos.
- Caché acotada de 60 segundos, solicitudes simultáneas agrupadas, refresh forzado, validación de inputs, rechazo de solicitudes de otro origen, paginación acotada y política de rate limits reutilizable.
- Errores del servidor traducidos sin exponer credenciales o respuestas crudas.

## Lo que falta para datos reales

1. Conectar **Meta Ads MCP**, diferente de Social Technologies MCP. No se debe cambiar de endpoint a ciegas ni copiar tokens de DevTools.
2. Inspeccionar herramientas y schemas de esa conexión, las cuentas accesibles, las acciones, sus permisos y paginación. `scripts/discover-mcp.ts` permite descubrimiento de un endpoint Streamable HTTP configurado en el servidor. Es una utilidad de inspección, no un adaptador de Ads terminado ni una implementación OAuth.
3. Implementar `lib/mcp/provider.ts` con acciones explícitas verificadas. No crear un proxy genérico de herramientas. El proveedor actual responde con un error de capacidad y no llama una API imaginaria.
4. Antes de habilitar la rama Meta en `app/api/dashboard/route.ts`, exigir identidad autenticada y autorización por cliente/cuenta, y sustituir el bloqueo explícito. La separación por tenant de la caché está preparada; el onboarding multiusuario y ACL persistentes aún no están implementados.
5. Verificar semántica de resultados, evento/destino, atribución y fecha. Contrastar cifras con Ads Manager antes de aprobar el MVP conectado.

Un MCP disponible para este chat no se convierte automáticamente en una conexión permanente para visitantes del sitio. Para Sites debe verificarse elegibilidad y usar su puente autenticado de conectores. Para un backend independiente se necesita configuración y autenticación de servidor propias. No se han declarado conectores de DevTools en el sitio, porque no resuelven las consultas publicitarias.

## Documentación

- [MCP validado y conexión server-only](docs/mcp-conectado.md)

- [Investigación y matriz de métricas](docs/capacidades.md)
- [Arquitectura, modelo y contrato del proveedor](docs/arquitectura.md)
- [Validación y criterios pendientes](docs/validacion.md)

## Agregar una métrica

Agregar una definición en `lib/metrics/config.ts`: ID, campos de referencia, etiqueta, formato, disponibilidad, niveles, tooltip y cálculo. La tabla y el selector de columnas la incorporan desde ese catálogo. El proveedor debe habilitar la fuente comprobada y normalizar sus valores; agregar una etiqueta no crea disponibilidad en Meta. Las acciones requieren un mapeo explícito de semántica sin sumar alias solapados.

## Seguridad y operación

No hay tokens en frontend, código, historial Git ni archivos de ejemplo. El modo Meta está deshabilitado hasta contar con un proveedor validado. El sitio se prepara como privado del propietario. No ampliar su audiencia hasta implementar el modelo de autorización de clientes. La caché de memoria no persiste históricos ni se comparte entre procesos; para producción con varios workers debe reemplazarse por almacenamiento de caché aislado y con TTL. Grandes reportes requieren paginación de servidor y posiblemente trabajos asíncronos; la UI actual pagina el conjunto cargado.

La base Vinext proviene del starter de Sites y está fijada por lockfile. Validar compatibilidad del framework antes de una operación multiempresa con SLA.
