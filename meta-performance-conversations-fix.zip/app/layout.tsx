import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Adscope · Meta Performance",
  description: "Análisis de campañas, conjuntos y anuncios con métricas verificables.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">{children}</body>
    </html>
  );
}
