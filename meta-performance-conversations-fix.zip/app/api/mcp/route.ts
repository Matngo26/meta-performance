import { MarketingApiAdsProvider } from '@/lib/providers/marketing-api-ads';
import { DataError, safeError } from '@/lib/services/errors';
import { serverEnv } from '@/lib/config/server-env';

export const dynamic='force-dynamic';
function auth(request: Request) { const expected=serverEnv('META_MCP_BEARER'); const received=request.headers.get('authorization')?.replace(/^Bearer\s+/i,''); if(!expected || !received || received!==expected) throw new DataError('UNAUTHORIZED','MCP bridge authentication failed.',401); }
export async function GET() { return Response.json({name:'meta-ads-bridge',protocol:'json-rpc-2.0',status:'ok'}); }
export async function POST(request: Request) {
  try { auth(request); const body=await request.json() as {id?:number|string;method?:string;params?:{name?:string;arguments?:Record<string,unknown>}}; const id=body.id??null; const provider=new MarketingApiAdsProvider();
    if(body.method==='tools/list') return Response.json({jsonrpc:'2.0',id,result:{tools:[{name:'get_ad_accounts',description:'List accessible Meta ad accounts',inputSchema:{type:'object'}},{name:'get_ad_entities',description:'Query Meta Ads insights at campaign, adset, or ad level',inputSchema:{type:'object'}},{name:'get_field_context',description:'Return supported dashboard fields',inputSchema:{type:'object'}}]}});
    if(body.method!=='tools/call') throw new DataError('METHOD','Unsupported MCP method.',400);
    const name=body.params?.name; const args=body.params?.arguments??{};
    if(name==='get_field_context') return Response.json({jsonrpc:'2.0',id,result:{content:[{type:'text',text:JSON.stringify({fields:['id','name','spend','impressions','reach','frequency','inline_link_clicks','clicks','actions','campaign_id','campaign_name','adset_id','adset_name','ad_id','ad_name','effective_status','objective','optimization_goal']})}]}});
    if(name==='get_ad_accounts') { const data=await provider.accounts({tenantId:'mcp',userId:'mcp'}); return Response.json({jsonrpc:'2.0',id,result:{content:[{type:'text',text:JSON.stringify(data)}]}}); }
    if(name==='get_ad_entities') { const q=args as any; const report=await provider.report({tenantId:'mcp',userId:'mcp'},{accountId:String(q.account_id),since:String(q.since),until:String(q.until),level:q.level==='adset'?'adset':q.level==='campaign'?'campaign':'ad',filters:{search:'',campaignId:'',adSetId:'',adId:'',status:'',objective:''}}); return Response.json({jsonrpc:'2.0',id,result:{content:[{type:'text',text:JSON.stringify(report)}]}}); }
    throw new DataError('TOOL','Unsupported MCP tool.',400);
  } catch(error) { const status=error instanceof DataError?error.status:502; return Response.json({jsonrpc:'2.0',id:null,error:{code:-32000,data:safeError(error)}},{status}); }
}
