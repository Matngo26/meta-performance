import { z } from 'zod';
import { demoProvider } from '@/lib/services/demo-provider';
import { metaProvider } from '@/lib/mcp/provider';
import { QueryCache } from '@/lib/cache/query-cache';
import { DataError,safeError } from '@/lib/services/errors';
import { isDate } from '@/lib/utils/dates';
import { getChatGPTUser } from '@/app/chatgpt-auth';
import type { Report } from '@/types/domain';
export const dynamic='force-dynamic';
const cache=new QueryCache<Report>();
const text=z.string().max(200);
const schema=z.object({operation:z.enum(['accounts','report']),mode:z.enum(['meta','mock']),force:z.boolean().optional(),query:z.object({accountId:text,since:text.refine(isDate),until:text.refine(isDate),level:z.enum(['campaign','adset','ad']),filters:z.object({search:text,campaignId:text,adSetId:text,adId:text,status:text,objective:text})}).optional()}).strict();
const json=(data:unknown,status=200,retryAfter?:number)=>Response.json(data,{status,headers:{'Cache-Control':'private, no-store',...(retryAfter?{'Retry-After':String(retryAfter)}:{})}});
export async function POST(request:Request) {
 try {
  const origin=request.headers.get('origin');
  const requestUrl=new URL(request.url);
  const forwardedHost=request.headers.get('x-forwarded-host');
  const requestHost=forwardedHost??request.headers.get('host')??requestUrl.host;
  let originHost='';try{originHost=origin?new URL(origin).host:'';}catch{originHost='';}
  const sameOrigin=!origin||origin===requestUrl.origin||originHost===requestHost||originHost.endsWith('.app.github.dev')||originHost.endsWith('.github.dev');
  const localDevelopment=process.env.NODE_ENV!=='production';
  if(!localDevelopment&&!sameOrigin)throw new DataError('ORIGIN','Solicitud no permitida.',403);
  const bodyText=await request.text();if(bodyText.length>10000)throw new DataError('INPUT','Solicitud demasiado grande.',413);
  let body;try{body=schema.parse(JSON.parse(bodyText));}catch{throw new DataError('INPUT','Revisá las fechas y filtros seleccionados.',400);}
  const user=await getChatGPTUser();const scope={tenantId:user?.userId??'local-development',userId:user?.userId??'local-development'};
  const provider=body.mode==='mock'?demoProvider:metaProvider;
  if(body.operation==='accounts')return json({accounts:await provider.accounts(scope),capabilities:await provider.capabilities()});
  const query=body.query;if(!query||query.since>query.until||(Date.parse(query.until)-Date.parse(query.since))/86400000>92)throw new DataError('DATES','Elegí un rango válido de hasta 93 días.',400);
  const accounts=await provider.accounts(scope);if(!accounts.some(a=>a.id===query.accountId))throw new DataError('ACCOUNT_DENIED','No tenés acceso a esta cuenta.',403);
  const key=JSON.stringify([scope,body.mode,query]);const report=await cache.get(key,()=>provider.report(scope,query),body.force);return json({report});
 }catch(error){return json({error:safeError(error)},error instanceof DataError?error.status:502,error instanceof DataError?error.retryAfter:undefined);}
}
